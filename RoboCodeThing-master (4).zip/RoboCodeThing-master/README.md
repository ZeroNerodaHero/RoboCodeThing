# RoboCodeThing
PUT THE STRATEGY HERE:
Randomize a number of moves, the HAVEATITBOT won't be able to tell what it is doing
When see fire, change directions.

NOTES FOR OTHER PPL
-Cats are bad
